BRIDGE SPATIAL INTELLIGENCE — GITHUB PAGES UPLOAD PACKAGE

Upload everything inside the dist folder to the root of the GitHub repository.
Keep the assets folder and its contents together.

Required structure:
index.html
styles.css
script.js
assets/bridge-b-mark.jpg
assets/hero-spatial-landscape.png

The website is a static site and does not require a database or server runtime.
